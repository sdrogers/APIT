
public class BadKeywordException extends Exception {

}
